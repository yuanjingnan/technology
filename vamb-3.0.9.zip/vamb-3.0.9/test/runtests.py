import parsecontigs
import parsebam
import encode
