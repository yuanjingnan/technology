#!/usr/bin/perl
#Author: liaoxinhui@genomics.org.cn
#Date:  Wed Sep 30 12:23:01 CST 2015
#Modified: licong, liuchichuan

use strict;
use warnings;
use Getopt::Long;
use FindBin '$Bin';
use Cwd 'abs_path';
use File::Basename;
use lib "$Bin/../self_perllib";
use CommonMethods;

my ($conf,$list);
GetOptions (
	"conf:s" => \$conf,
	"list:s" => \$list
);

if (!$conf || !$list) {
	print STDERR <<USAGE;
=============================================================================
Descriptions: Generate shell scripts for reads filtering
Usage:
	perl $0 [options]
Options:
	* -conf          input software parameters and file paths info
	* -list          input raw data file list
E.g.:
	perl $0 -conf para.conf -list rawdata.list
=============================================================================
USAGE
	exit;
}

my (%para, %sample,%totalbase, %cleandata1, %cleandata2, %rawdata1, %rawdata2) = ();
open CONF,$conf or die $!;
while (<CONF>) {
	next if (/^\s*$/ || /^\s*#/ || !/=/);
	chomp; s/^([^#]+)#.*$/$1/;
	my ($key,$value) = split /=/,$_,2;
	$key =~ s/^\s*(.*?)\s*$/$1/;
	$value =~ s/^\s*(.*?)\s*$/$1/;
	next if ($value =~ /^\s*$/);
	$para{$key} = $value;
    #print $key,"\n",$value;
}
close CONF;

my @a;
open LIST,$list or die $!;
while (<LIST>) {
	next if (/^\s*$/ || /^\s*#/);
	chomp; my @t = split /\s+/;
	@a = split /,+/, $t[2];
	if(@a > 1)	# PE reads
	{
		$sample{$t[0]}{$t[1]} = [$a[0], $a[1], $t[3], $t[4], $t[5]]; # fq1, fq2, reads length, insert size, raw base
		$totalbase{$t[0]} += $sample{$t[0]}{$t[1]}[-1]; 	
	}
	else		# SE reads
	{
		$sample{$t[0]}{$t[1]} = [$t[2], $t[3], $t[4], $t[5]];
		$totalbase{$t[0]} += $sample{$t[0]}{$t[1]}[-1];
	}
}
close LIST;

for('CleanGnum','SOAPnuke_Options',
	'Shell_Dir','Result_Dir','Cp_Dir','Mv_Dir',		#Cp_Dir:Report	Mv_Dir:Upload
	'Depend_List','DownStream_List','Seq_Platform') {
	 unless (defined $para{$_}) {ThrowError("ERROR: Can't find parameter [$_]!\n",*STDERR)}
}

my $soapnuke_para = $para{'SOAPnuke_Options'};
$soapnuke_para .= ($para{'Seq_Platform'} =~ /hiseq2000/i) ? " -5 0 " : " -5 1 ";
#$soapnuke_para .= ($para{'Seq_Platform'} =~ /hiseq2000/i) ? " -Q 1 -5 0 " : " -Q 2 -5 1 ";
 my $seq_type = ($para{'Seq_Platform'} =~ /hiseq2000/i) ? "-seqType 0 " : "-seqType 1 ";
$seq_type="-seqType 2 " if($para{'Seq_Platform'} =~ /500/ || $para{'Seq_Platform'} =~ /BGISEQ/i);
$soapnuke_para =~ s/-5 1// if($para{'Seq_Platform'} =~ /500/ || $para{'Seq_Platform'} =~ /BGISEQ/i);
#my $fqcheck = ($para{'Seq_Platform'} =~ /hiseq2000/i) ? "$Bin/../software/fqcheck" : "$Bin/../software/fqcheck33";
my $fqcheck = "$Bin/../Bin_CentOS6/iTools Fqtools fqcheck ";
my $findN="$Bin/N_filter_V4.pl";
$findN="$Bin/findNtile.pl" if($para{'Seq_Platform'} =~ /500/ || $para{'Seq_Platform'} =~ /BGISEQ/i);

open DEPL,">$para{'Depend_List'}" or die $!;
open DOWL,">$para{'DownStream_List'}" or die $!;
$para{'Depend_List'}=~s/monitor/result/g;
open RES,">$para{'Depend_List'}" or die $!;
my $filter_shell = "";
my $soapnuke_version="$Bin/../Bin_CentOS6/SOAPnuke";

#$para{'soapnuke_version'}='2.1.0';
if ($para{'soapnuke_version'} eq '2.1.0'){
$soapnuke_version="$Bin/../Bin_CentOS6/SOAPnuke2.1.0";
}
my @depends = ();

foreach my $s (keys %sample) 
{
	#`mkdir -p $para{'Shell_Dir'}/$s`;
	#`mkdir -p $para{'Result_Dir'}/$s`;
	
	my @merge_depends = ();
	foreach my $lane ( keys %{$sample{$s}} )
	{
		my $shdir = Mkdir("$para{'Shell_Dir'}/$s/$s\_$lane");
		my $outdir = Mkdir("$para{'Result_Dir'}/$s/$s\_$lane");
		#my $cut_reads_num = int($para{'CleanGnum'}*1000000000*$sample{$s}{$lane}[-1]/($totalbase{$s}*$sample{$s}{$lane}[-3]*1024*1024)*1.1+0.5);
		# my $cut_reads_num = int($para{'CleanGnum'}*1000000000*$sample{$s}{$lane}[-1]/($totalbase{$s}*$sample{$s}{$lane}[-3]*1024*1024))+1;
		# $cut_reads_num = int($para{'CleanGnum'}*1000000000*$sample{$s}{$lane}[-1]/(2*$totalbase{$s}*$sample{$s}{$lane}[-3]*1024*1024))+1 if(@a > 1);
		# $cut_reads_num = 0 if ( $para{'CleanGnum'} == 0 );
		my $cut_reads_num = "";
		if ( $para{'CleanGnum'} >= 1 ){
            my @lanes_num = keys %{$sample{$s}};
            my $lane_num = @lanes_num;
            my $lane_cleangnum = int($para{'CleanGnum'}/$lane_num)+1;
			$cut_reads_num = "-L $lane_cleangnum";
		}elsif( $para{'CleanGnum'} > 0){
                    $cut_reads_num = "-L $para{'CleanGnum'}"
                }else{
                    $cut_reads_num = "";       
                }

		my ($fq_1, $fq_2, $fq2_2,$adp_5, $adp_3)=("","","","","");
		if ($para{'Filter_Adp5'} && $para{'Filter_Adp3'}) 
		{
			$adp_5 = $para{'Filter_Adp5'};
			$adp_3 = $para{'Filter_Adp3'};
		}
		else 
		{
			die"WARN: Filter_Adp5 and Filter_Adp3 have to be provided !\n";
		}
		
		
			$fq_1 = $sample{$s}{$lane}[0];
			$fq_2 = $sample{$s}{$lane}[1] if(@a > 1);
			print STDERR "WARN: the raw data of sample [$s] is not enough, ignoring!\n" if ( $totalbase{$s} < $para{'CleanGnum'} );
			
			if($para{'Seq_Platform'} =~ /500/ || $para{'Seq_Platform'} =~ /BGISEQ/i)
			{
				if(@a > 1)
				{
					$filter_shell = "tile=`$Bin/../Bin_CentOS6/perl $findN -fq1 $fq_1 -fq2 $fq_2 $seq_type` && \\\n";
				}
				else
				{
					$filter_shell = "tile=`$Bin/../Bin_CentOS6/perl $findN -fq1 $fq_1 $seq_type` && \\\n";
				}
			}
			else
			{
				if(@a > 1)
				{
					$filter_shell = "$Bin/../Bin_CentOS6/perl $findN -fq1 $fq_1 -fq2 $fq_2 -o $outdir && \\\n";
				}
				else
				{
					$filter_shell = "$Bin/../Bin_CentOS6/perl $findN -fq1 $fq_1 -o $outdir && \\\n";
				}
				$filter_shell .= "tile=`cat $outdir/N_tile.txt` && \\\n";
			}
			$fq2_2 = "-2 $fq_2" if(@a > 1);
                        $filter_shell .= "export LD_LIBRARY_PATH=/share/app/gcc-5.2.0/lib64:\$LD_LIBRARY_PATH && \\\n";
			# $filter_shell .= "$Bin/../Bin_CentOS6/SOAPnuke1.5.6 filter $soapnuke_para -c $cut_reads_num -1 $fq_1 $fq2_2 -f $adp_3 -r $adp_5 \$tile -o $outdir -C $s\_$lane\_1.fq.gz -D $s\_$lane\_2.fq.gz -R $s\_$lane\_1.rawdata.fq.gz -W $s\_$lane\_2.rawdata.fq.gz && \\\n";
	        	$filter_shell .= "/ldfssz1/ST_CANCER/POL/SHARE/tools/SOAPnuke/SOAPnuke1.5.6 filter $soapnuke_para $cut_reads_num -1 $fq_1 $fq2_2 -f $adp_3 -r $adp_5 \$tile -o $outdir -C $s\_$lane\_1.fq.gz -D $s\_$lane\_2.fq.gz -R $s\_$lane\_1.rawdata.fq.gz -W $s\_$lane\_2.rawdata.fq.gz && \\\n";

		# remove the fq_1 fq_2 ,change in 2019/08/12
        #$filter_shell .= "if [ -e $fq_1];then rm $fq_1 ";
        #$filter_shell .= "$fq_2" if(@a > 1);
        #     $filter_shell .= ";fi && \\\n";
	        # remove the fq_1 fq_2 ,change in 2019/08/12
			# Mkshell("$shdir/Filter_$s\_$lane.sh",$filter_shell);

			$cleandata1{$s} .= "$outdir/$s\_$lane\_1.fq.gz ";
			$cleandata2{$s} .= "$outdir/$s\_$lane\_2.fq.gz " if(@a > 1);

			$rawdata1{$s} .= "$outdir/$s\_$lane\_1.rawdata.fq.gz ";
			$rawdata2{$s} .= "$outdir/$s\_$lane\_2.rawdata.fq.gz " if(@a > 1);

        	print RES "Filter_SOAPnuke\t$shdir/Filter_$s\_$lane.sh\t$outdir/$s\_$lane\_1.fq.gz\t0\n";
        	print RES "Filter_SOAPnuke\t$shdir/Filter_$s\_$lane.sh\t$outdir/$s\_$lane\_2.fq.gz\t0\n" if(@a > 1);


			$filter_shell .= "cd $outdir && \\\n";
			$filter_shell .= "$fqcheck -InFq1 $s\_$lane\_1.fq.gz -OutStat1 $s\_$lane\_1.fqcheck && \\\n";
			$filter_shell .= "$fqcheck -InFq1 $s\_$lane\_2.fq.gz -OutStat1 $s\_$lane\_2.fqcheck && \\\n" if(@a > 1);
			$filter_shell .= "$fqcheck -InFq1 $s\_$lane\_1.rawdata.fq.gz -OutStat1 $s\_$lane\_1.rawdata.fqcheck && \\\n rm $s\_$lane\_1.rawdata.fq.gz && \\\n";
			$filter_shell .= "$fqcheck -InFq1 $s\_$lane\_2.rawdata.fq.gz -OutStat1 $s\_$lane\_2.rawdata.fqcheck && \\\n rm $s\_$lane\_2.rawdata.fq.gz && \\\n" if(@a > 1);
			# add some shell to remove _1.rawdata.fq.gz and _2.rawdata.fq.gz, changed at 2019/08/12
			# $filter_shell .= "rm $s\_$lane\_1.rawdata.fq.gz $s\_$lane\_2.rawdata.fq.gz && \\\n";

			if(@a > 1)
			{
				$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/fqcheck_distribute.pl $s\_$lane\_1.fqcheck $s\_$lane\_2.fqcheck -o $s\_$lane. && \\\n";
			}	
			else
			{	
				$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/fqcheck_distribute.pl $s\_$lane\_1.fqcheck -o $s\_$lane. && \\\n";
			}
			$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/soapnuke_stat.pl $outdir/Basic_Statistics_of_Sequencing_Quality.txt $outdir/Statistics_of_Filtered_Reads.txt >$s\_$lane.filter.stat.xls && \\\n";
			$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/drawPizza.pl -infile $outdir/$s\_$lane.filter.stat.xls -outdir $outdir";
			# Mkshell("$shdir/FilterStat_$s\_$lane.sh",$filter_shell);
			Mkshell("$shdir/Filter_Stat_$s\_$lane.sh",$filter_shell);
			push @merge_depends, "$shdir/Filter_Stat_$s\_$lane.sh:1G:4cpu";

			# print DEPL "$shdir/Filter_$s\_$lane.sh:1G\t$shdir/FilterStat_$s\_$lane.sh:1G\n";

       		print RES "Filter_SOAPnuke\t$shdir/FilterStat_$s\_$lane.sh\t$outdir/$s\_$lane.filter.stat.xls\t1\n";
        	print RES "Filter_SOAPnuke\t$shdir/FilterStat_$s\_$lane.sh\t$outdir/$s\_$lane.RawReadsClass.png\t1\n";
			print RES "Filter_SOAPnuke\t$shdir/FilterStat_$s\_$lane.sh\t$outdir/$s\_$lane.base.png\t1\n";
			print RES "Filter_SOAPnuke\t$shdir/FilterStat_$s\_$lane.sh\t$outdir/$s\_$lane.qual.png\t1\n";
	}
	

	my $mvdir = Mkdir("$para{'Mv_Dir'}/$s");	#upload_directory
	my @n = keys %{$sample{$s}};
	my @lanenum = split (/\s+/, $cleandata1{$s});
	$filter_shell = "cd $para{'Result_Dir'}/$s && \\\n";
	# changed at 2019/08/12——C1, C2, C3, C4, C5, C6, C7, C8
	if (@lanenum == 1)
	{
		# C1 $filter_shell .= "mv $rawdata1{$s} $s\_1.rawdata.fq.gz && \\\n";
		# C2 $filter_shell .= "mv $rawdata2{$s} $s\_2.rawdata.fq.gz && \\\n" if (@a > 1);
		$filter_shell .= "mv $cleandata1{$s} $s\_1.fq.gz && \\\n";
		$filter_shell .= "mv $cleandata2{$s}  $s\_2.fq.gz && \\\n" if (@a > 1);
	}
	else
	{
		# C3 $filter_shell .= "cat $rawdata1{$s} > $s\_1.rawdata.fq.gz && \\\n";
		# C4 $filter_shell .= "cat $rawdata2{$s} > $s\_2.rawdata.fq.gz && \\\n" if (@a > 1);
		$filter_shell .= "cat $cleandata1{$s} > $s\_1.fq.gz && \\\n";
		$filter_shell .= "rm $cleandata1{$s} && \\\n";
		$filter_shell .= "cat $cleandata2{$s}  > $s\_2.fq.gz && \\\nrm $cleandata2{$s} && \\\n" if (@a > 1);
	}
	$filter_shell .= "$fqcheck -InFq1 $s\_1.fq.gz -OutStat1 $s\_1.fqcheck && \\\n";
	$filter_shell .= "$fqcheck -InFq1 $s\_2.fq.gz -OutStat1 $s\_2.fqcheck && \\\n" if (@a > 1);
	if(@a > 1)
    	{
		$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/fqcheck_distribute.pl $s\_1.fqcheck $s\_2.fqcheck -o $s. && \\\n";
    	}
    	else
    	{
		$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/fqcheck_distribute.pl $s\_1.fqcheck -o $s. && \\\n";
	}
	$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/filter_stat_mergelane.pl -indir $para{'Result_Dir'}/$s -outdir $para{'Result_Dir'}/$s && \\\n";	# produce Sample.filter.stat.xls
	$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/drawPizza.pl -infile $para{'Result_Dir'}/$s/$s.filter.stat.xls -outdir $para{'Result_Dir'}/$s && \\\n";
	# C5 $filter_shell .= "mv $s\_1.fq.gz $mvdir && \\\n";
	# C6 $filter_shell .= "mv $s\_2.fq.gz $mvdir && \\\n" if (@a > 1);
	$filter_shell .= "cp $s.filter.stat.xls $s.RawReadsClass.png $s.base.png $s.qual.png $para{'Cp_Dir'}"; 
	Mkshell("$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh",$filter_shell);
	push @depends, "$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh:0.5G";
	
			
	for(@merge_depends) {print DEPL "$_\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh:0.5G\n"};
	if (@a > 1)
	{
            # C7 print DOWL "$s\t$mvdir/$s\_1.fq.gz,$mvdir/$s\_2.fq.gz\t$sample{$s}{$n[0]}[-3]\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh:0.5G\n";
    		print DOWL "$s\t$para{'Result_Dir'}/$s/$s\_1.fq.gz,$para{'Result_Dir'}/$s/$s\_2.fq.gz\t$sample{$s}{$n[0]}[-3]\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh:0.5G\n";
	}
	else
	{		
		# C8 print DOWL "$s\t$mvdir/$s\_1.fq.gz\t$sample{$s}{$n[0]}[-3]\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh:0.5G\n";
		print DOWL "$s\t$para{'Result_Dir'}/$s/$s\_1.fq.gz\t$sample{$s}{$n[0]}[-3]\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh:0.5G\n";
	}
	print RES "Filter_SOAPnuke\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh\t$para{'Cp_Dir'}/$s.filter.stat.xls\t1\n";
    	print RES "Filter_SOAPnuke\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh\t$para{'Cp_Dir'}/$s.RawReadsClass.png\t1\n";
    	print RES "Filter_SOAPnuke\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh\t$para{'Cp_Dir'}/$s.base.png\t1\n";
    	print RES "Filter_SOAPnuke\t$para{'Shell_Dir'}/$s/merge_$s\_cleandata.sh\t$para{'Cp_Dir'}/$s.qual.png\t1\n";

}



$filter_shell = "$Bin/../Bin_CentOS6/perl $Bin/filter_stat.pl -indir $para{'Result_Dir'} -output $para{'Result_Dir'}/FilterSummary.xls && \\\n";
$filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/ATCG_diff.pl -indir $para{'Result_Dir'} -output $para{'Result_Dir'}/ATCG_separation.xls && \\\n";
if (-e "$para{'Result_Dir'}/../Rm_rRNA")
{
        $filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/get_Filter_SOAPnuke_stat.pl -indir $para{'Result_Dir'} -outdir $para{'Result_Dir'} -rRNAstat $para{'Result_Dir'}/../Rm_rRNA/rRNAremoved.rrna.stat.xls -separate $para{'Result_Dir'}/ATCG_separation.xls -species $para{'Species'} && \\\n";
}
else
{
        $filter_shell .= "$Bin/../Bin_CentOS6/perl $Bin/get_Filter_SOAPnuke_stat.pl -indir $para{'Result_Dir'} -outdir $para{'Result_Dir'} -separate $para{'Result_Dir'}/ATCG_separation.xls -species $para{'Species'} && \\\n";
}
$filter_shell .= "cp $para{'Result_Dir'}/FilterSummary.xls $para{'Cp_Dir'} && \\\n";
# $filter_shell .= "cd $para{'Mv_Dir'}/../ && \\\n";
# $filter_shell .= "md5sum CleanData/*/*fq.gz > md5.txt && \\\n";
# add shell command for remove at 2019/08/07 start
$filter_shell .= "rm -f $para{'Result_Dir'}/*/*.rawdata.fq.gz ||:";
# add shell command for remove at 2019/08/07 end

Mkshell("$para{'Shell_Dir'}/Filter_stat.sh",$filter_shell);
for(@depends) {print DEPL "$_\t$para{'Shell_Dir'}/Filter_stat.sh:1G\n"};


print RES "Filter_SOAPnuke\t$para{'Shell_Dir'}/Filter_stat.sh\t$para{'Result_Dir'}/FilterSummary.xls\t1\n";
print RES "Filter_SOAPnuke\t$para{'Shell_Dir'}/Filter_stat.sh\t$para{'Result_Dir'}/Filter_SOAPnuke.stat.xls\t0\n";

print STDERR "DONE";
