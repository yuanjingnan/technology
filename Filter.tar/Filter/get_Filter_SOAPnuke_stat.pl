#!/usr/bin/perl -w
use Cwd 'abs_path';
use File::Basename;
use FindBin '$Bin';
use Getopt::Long;

my $usage=<<INFO;

Description:
usage:
        perl $0 [options]
options:
	*-indir:
	*-outdir:
	-rRNAstat:
	*-separate:
	*-species:
	-QC:
	-sample:
	-help|?: help information
example:

author:libinbin
edited:liuchichuan

INFO

my ($indir, $outdir, $rRNAstat, $separate, $species, $QC, $sample, $help);
GetOptions(
	"-indir:s" => \$indir,
	"-outdir:s" => \$outdir,
	"-rRNAstat:s" => \$rRNAstat,
	"-separate:s" => \$separate,
	"-species:s" => \$species,
	"-QC:s" => \$QC,
	"-sample:s" => \$sample,
	"help|?" => \$help
);
if (!defined $indir || !defined $outdir || !defined $separate || !defined $species || defined $help) 
{
        die "$usage";
        exit 1;
}

$indir=abs_path($indir);
$outdir=abs_path($outdir);

my $QC_database;
if(defined $QC){
	$QC_database=$QC;
	$QC_database=~s/G/000000000/;
	$QC_database=~s/g/000000000/;
}

system("/bin/ls -l $indir/*/*/Statistics_of_Filtered_Reads.txt |awk '{print \$9}' >$outdir/Statistics_of_Filtered_Reads.txt.list") ;
system("/bin/ls -l $indir/*/*/*.stat.xls |awk '{print \$9}' >$outdir/Statistics_of_Filtered.list");


my %hash;
my %hash_sample;

if (defined $rRNAstat)
{
	open IN, "$rRNAstat" or die $!;
	while(<IN>)
	{
		chomp;
		my @temp=split /\t/,$_;
		$hash{TotalRawReads}{$temp[0]}=$temp[1];
		$hash{TotalrRNAFilter}{$temp[0]}=$temp[2];
	}
	close IN;
}

open SEP, "$separate" or die $!;
while(<SEP>)
{
	chomp;
	next if $.==1;
	my @temp=split /\t/,$_;
	my ($name, $num) = $temp[0] =~ /(.*)\_(\d+)\.fq$/;
	if ($num == 1)
	{
		$hash{ATseparateofFq1}{$name} = $temp[1];
		$hash{CGseparateofFq1}{$name} = $temp[2];
	}
	elsif ($num ==2)
	{
		$hash{ATseparateofFq2}{$name} = $temp[1];
		$hash{CGseparateofFq2}{$name} = $temp[2];
	}
	$hash{ATseparateofFq2}{$name} ||= NA;					#SE
	$hash{CGseparateofFq2}{$name} ||= NA;
}
close SEP;


open IN,"$outdir/Statistics_of_Filtered.list" or die $!;
while(<IN>)
{
	chomp;
	my $file=$_;
	my ($filename,$dirs) = fileparse($file);
	$filename=~s/\.filter\.stat\.xls//g;
	$hash_sample{$filename}='';
	open INQ,"$file";
	while(<INQ>)
	{
		chomp;
		my $line=$_;
		my @temp=split /\t/,$line;
		$temp[0] =~s/\s+//g;
		if($temp[0] =~ /NumberofReads/)
		{
			$hash{ProjectRawReads}{$filename}=$temp[1];
			$hash{ProjectCleanReads}{$filename}=$temp[2];
		}
		if($temp[0] =~ /DataSize/)
		{
			$hash{ProjectCleanReadsBases}{$filename}=$temp[2];
		}
		if($temp[0] =~ /GC\(\%\)offq1/)
		{
			$hash{GCofFq1}{$filename}=$temp[2]."%";
		}
		if($temp[0] =~ /GC\(\%\)offq2/)
		{
			$hash{GCofFq2}{$filename}=$temp[2]."%" if ($temp[2] != 0);
			$hash{GCofFq2}{$filename} ||= NA;								#SE
		}
		if($temp[0] =~ /Q20\(\%\)offq1/)
		{
			$hash{Q20ofFq1}{$filename}=$temp[2]."%";
		}
		if($temp[0] =~ /Q20\(\%\)offq2/)
		{
			$hash{Q20ofFq2}{$filename}=$temp[2]."%" if (defined $temp[2]);
			$hash{Q20ofFq2}{$filename} ||= NA ;
		}
		if($temp[0] =~ /Q30\(\%\)offq1/)
		{
			$hash{Q30ofFq1}{$filename}=$temp[2]."%";
		}
		if($temp[0] =~ /Q30\(\%\)offq2/)
		{
			$hash{Q30ofFq2}{$filename}=$temp[2]."%" if (defined $temp[2]);
			$hash{Q30ofFq2}{$filename} ||= NA ;
		}
	}
	close INQ;
}
close IN;


open IN,"$outdir/Statistics_of_Filtered_Reads.txt.list" or die $!;
while(<IN>){
	chomp;
	my $file=$_;
	my @temp=split /\//,$_;
	my $filename=$temp[-2];
	open INF,"$file";
	while(<INF>){
		chomp;
		my $line=$_;
		my @temp=split /\t/,$line;
		$temp[0] =~s/\s+//g;
		$temp[1] =~s/\s+//g;
                $hash{Readswithadapter}{$filename}=0;
		if($temp[0] =~ /Readswithadapter/){
			$hash{Readswithadapter}{$filename}=$temp[1];
		}
                $hash{Readswithlowquality}{$filename}=0;
		if($temp[0] =~ /Readswithlowquality/){
			$hash{Readswithlowquality}{$filename}=$temp[1];
		}
#		if($temp[0] =~ /Readswithduplications/){
#			$hash{Readswithduplications}{$filename}=$temp[1];
#		}
                $hash{Readswithnrateexceed}{$filename}=0;
		if($temp[0] =~ /Readswithnrateexceed/){
			$hash{Readswithnrateexceed}{$filename}=$temp[1];
		}
		# if($temp[0] =~ /Readwithsmallinsertsize/){
			# $hash{Readwithsmallinsertsize}{$filename}=$temp[1];
		# }
		# if($temp[0] =~ /ReadswithPolyA/){
			# $hash{ReadswithPolyA}{$filename}=$temp[1];
		# }
	}
	close INF;
}
close IN;


open OUT,">$outdir/Filter_SOAPnuke.stat.temp" or die $!;
foreach my $i (sort keys %hash_sample)
{
		my $TotalrRNAFilter_ratio=sprintf("%.3f",100*$hash{TotalrRNAFilter}{$i}/$hash{TotalRawReads}{$i})."%" if (defined $hash{TotalrRNAFilter}{$i} && defined $hash{TotalRawReads}{$i});
		my $Projectcleanreads_ratio=sprintf("%.3f",100*$hash{ProjectCleanReads}{$i}/$hash{ProjectRawReads}{$i})."%";
		my $Readswithadapter_ratio=sprintf("%.3f",100*$hash{Readswithadapter}{$i}/$hash{ProjectRawReads}{$i})."%";
		my $Readswithlowquality_ratio=sprintf("%.3f",100*$hash{Readswithlowquality}{$i}/$hash{ProjectRawReads}{$i})."%";
#		my $Readswithduplications_ratio=sprintf("%.3f",100*$hash{Readswithduplications}{$i}/$hash{ProjectRawReads}{$i})."%";
        my $Readswithnrateexceed_ratio=sprintf("%.3f",100*$hash{Readswithnrateexceed}{$i}/$hash{ProjectRawReads}{$i})."%";
		# my $Readwithsmallinsertsize_ratio=sprintf("%.3f",100*$hash{Readwithsmallinsertsize}{$i}/$hash{ProjectRawReads}{$i})."%";
		# my $ReadswithPolyA_ratio=sprintf("%.3f",100*$hash{ReadswithPolyA}{$i}/$hash{ProjectRawReads}{$i})."%";
		if (defined $rRNAstat)
		{
			print OUT "$i\t$species\t$hash{TotalRawReads}{$i}\t$hash{TotalrRNAFilter}{$i}\t$TotalrRNAFilter_ratio\t$hash{ProjectRawReads}{$i}\t$hash{ProjectCleanReads}{$i}\t$hash{ProjectCleanReadsBases}{$i}\t$Projectcleanreads_ratio\t$hash{Readswithadapter}{$i}\t$Readswithadapter_ratio\t$hash{Readswithlowquality}{$i}\t$Readswithlowquality_ratio\t$hash{Readswithnrateexceed}{$i}\t$Readswithnrateexceed_ratio\t$hash{ATseparateofFq1}{$i}\t$hash{ATseparateofFq2}{$i}\t$hash{CGseparateofFq1}{$i}\t$hash{CGseparateofFq2}{$i}\t$hash{GCofFq1}{$i}\t$hash{GCofFq2}{$i}\t$hash{Q20ofFq1}{$i}\t$hash{Q20ofFq2}{$i}\t$hash{Q30ofFq1}{$i}\t$hash{Q30ofFq2}{$i}\n";
		}
		elsif ( !defined $rRNAstat) 
		{
			print OUT "$i\t$species\tNA\tNA\tNA\t$hash{ProjectRawReads}{$i}\t$hash{ProjectCleanReads}{$i}\t$hash{ProjectCleanReadsBases}{$i}\t$Projectcleanreads_ratio\t$hash{Readswithadapter}{$i}\t$Readswithadapter_ratio\t$hash{Readswithlowquality}{$i}\t$Readswithlowquality_ratio\t$hash{Readwithnrateexceed}{$i}\t$Readwithnrateexceed_ratio\t$hash{ATseparateofFq1}{$i}\t$hash{ATseparateofFq2}{$i}\t$hash{CGseparateofFq1}{$i}\t$hash{CGseparateofFq2}{$i}\t$hash{GCofFq1}{$i}\t$hash{GCofFq2}{$i}\t$hash{Q20ofFq1}{$i}\t$hash{Q20ofFq2}{$i}\t$hash{Q30ofFq1}{$i}\t$hash{Q30ofFq2}{$i}\n";
		}
}
close OUT;

open OUT,">$outdir/Filter_SOAPnuke.stat.head" or die $!;
print OUT "Sample\tSpecies\tTotalRawReads\tTotalrRNAFilterReads\tTotalrRNAFilterReadsRatio\tProjectRawReads\tProjectCleanReads\tProjectCleanReadsBases\tProjectCleanReadsRatio\tReadsWithAdapter\tReadsWithAdapterRatio\tReadsWithLowQuality\tReadsWithLowQualityRatio\tReadWithNRateExceed\tReadWithNRateExceedRatio\tATseparateRatioofFq1\tATseparateRatioofFq2\tCGseparateRatioofFq1\tCGseparateRatioofFq2\tGCofFq1\tGCofFq2\tQ20ofFq1\tQ20ofFq2\tQ30ofFq1\tQ30ofFq2\n";
close OUT;

system("cat $outdir/Filter_SOAPnuke.stat.head $outdir/Filter_SOAPnuke.stat.temp >$outdir/Filter_SOAPnuke.stat.xls");

system("rm $outdir/Filter_SOAPnuke.stat.head $outdir/Filter_SOAPnuke.stat.temp $outdir/Statistics_of_Filtered_Reads.txt.list $outdir/Statistics_of_Filtered.list");


if (defined $QC){
	open IN,"$outdir/Filter_SOAPnuke.stat.xls" or die $!;
	<IN>;
	while(<IN>){
		chomp;
		my @temp=split /\t/,$_;
		if(defined $sample){
			if($sample eq $temp[0] && $temp[3]<$QC_database){
				die "\nError: $sample less then $QC \nPlease check file : $outdir/Filter_SOAPnuke.stat.xls\n\n";
			}
		}
		else{
			if($temp[3]<$QC_database){
				die "\nError: Some samples less then $QC \nPlease check file : $outdir/Filter_SOAPnuke.stat.xls\n\n";
			}
		}
	}
	close IN;
}
