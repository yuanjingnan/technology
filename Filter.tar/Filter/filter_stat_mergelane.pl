#!/usr/bin/perl
#Author: liuchichuan@genomics.cn
#Date:   20180227


use strict;
use warnings;
use Getopt::Long;
use FindBin '$Bin';
use Cwd 'abs_path';
use File::Basename;

my ($indir, $outdir);
GetOptions(
	"indir:s" => \$indir,
	"outdir:s" => \$outdir
);

if (! $indir || ! $outdir) 
{
	die "usage: perl $0 -indir indir -outdir outdir\n";
}


my %stat = ();

foreach my $f (glob("$indir/*/*.filter.stat.xls")) 
{
	my ($name) = $f =~ /.*\/(.*)\/.*\/.*filter.stat.xls/;	#sample name
	open F,$f or die $!;
	while (<F>) 
	{
		next if (/^\s*$/ || /^#/);
		chomp; 
		my @a = split /\t+/;
		if (/Number of Reads/) 
		{
			$stat{$name}{'raw_reads'} += $a[1];
			$stat{$name}{'clean_reads'} += $a[2];
		}
		elsif (/Data Size/) 
		{
			$stat{$name}{'raw_bases'} += $a[1];
			$stat{$name}{'clean_bases'} += $a[2];
		}
		elsif (/N of fq1/)
		{
			$stat{$name}{'raw_N_fq1'} += $a[1];
			$stat{$name}{'clean_N_fq1'} += $a[2];
		}
		elsif (/N of fq2/ && $a[1] ne "")
		{
			$stat{$name}{'raw_N_fq2'} += $a[1];
			$stat{$name}{'clean_N_fq2'} += $a[2];
		}
		elsif (/Discard Reads related to N/) 
		{
			$stat{$name}{'N'} += $a[1];
		}
		elsif (/Discard Reads related to low qual/) 
		{
			$stat{$name}{'low_qual'} += $a[1];
		}
		elsif (/Discard Reads related to Adapter/) 
		{
			$stat{$name}{'Adapter'} += $a[1];
		}
	}
	close F;
	
	foreach my $ck (glob("$indir/$name\_[1-2].fqcheck"))
	{
		my ($tag) = $ck =~ /.*\/$name\_(\d+).fqcheck/;
		open CK, $ck or die $!;
		while (<CK>)
		{
			next if (/^\s*$/ || /^#/);
			chomp;
			my @sp = split (/\t+/, $_);
			if ( $sp[0] =~ /^\d+/ )
			{
				$stat{$name}{"GC_$tag"} = $sp[1];	# $tag= 1/2 
				$stat{$name}{"q20_$tag"} = $sp[2];
				$stat{$name}{"q30_$tag"} = $sp[3];
			}
		}
		close CK;
	}



	open O,">$outdir/$name.filter.stat.xls" or die $!;
	if ( defined $stat{$name}{'raw_N_fq2'} ) #PE
	{
		print O "Type\tRaw data\tClean data\n";
		print O "Number of Reads\t$stat{$name}{'raw_reads'}\t$stat{$name}{'clean_reads'}\n";
		print O "Data Size\t$stat{$name}{'raw_bases'}\t$stat{$name}{'clean_bases'}\n";
		print O "N of fq1\t$stat{$name}{'raw_N_fq1'}\t$stat{$name}{'clean_N_fq1'}\n";
		print O "N of fq2\t$stat{$name}{'raw_N_fq2'}\t$stat{$name}{'clean_N_fq2'}\n";
		print O "GC(%) of fq1\t-\t$stat{$name}{'GC_1'}\n";
		print O "GC(%) of fq2\t-\t$stat{$name}{'GC_2'}\n";
		print O "Q20(%) of fq1\t-\t$stat{$name}{'q20_1'}\n";
		print O "Q20(%) of fq2\t-\t$stat{$name}{'q20_2'}\n";
		print O "Q30(%) of fq1\t-\t$stat{$name}{'q30_1'}\n";
		print O "Q30(%) of fq2\t-\t$stat{$name}{'q30_2'}\n";
		print O "Discard Reads related to N\t$stat{$name}{'N'}\n";
		print O "Discard Reads related to low qual\t$stat{$name}{'low_qual'}\n";
		print O "Discard Reads related to Adapter\t$stat{$name}{'Adapter'}\n";
	}
	else	#SE
	{
		print O "Type\tRaw data\tClean data\n";	
		print O "Number of Reads\t$stat{$name}{'raw_reads'}\t$stat{$name}{'clean_reads'}\n";
		print O "Data Size\t$stat{$name}{'raw_bases'}\t$stat{$name}{'clean_bases'}\n";
		print O "N of fq1\t$stat{$name}{'raw_N_fq1'}\t$stat{$name}{'clean_N_fq1'}\n";
		print O "N of fq2\t\t\n";
		print O "GC(%) of fq1\t-\t$stat{$name}{'GC_1'}\n";
		print O "GC(%) of fq2\t-\t-\n";
		print O "Q20(%) of fq1\t-\t$stat{$name}{'q20_1'}\n";
		print O "Q20(%) of fq2\t-\t-\n";
		print O "Q30(%) of fq1\t-\t$stat{$name}{'q30_1'}\n";
		print O "Q30(%) of fq2\t-\t-\n";
		print O "Discard Reads related to N\t$stat{$name}{'N'}\n";
		print O "Discard Reads related to low qual\t$stat{$name}{'low_qual'}\n";
		print O "Discard Reads related to Adapter\t$stat{$name}{'Adapter'}\n";
	}
	close O;
}


