#!/usr/bin/perl
#Author: liaoxinhui@genomics.org.cn
#Date:  Thu Jul  9 04:02:19 CST 2015


use strict;
use warnings;
use Getopt::Long;
use FindBin '$Bin';
use Cwd 'abs_path';
use File::Basename;

my ($indir, $output);
GetOptions(
	"indir:s" => \$indir,
	"output:s" => \$output
);

if (! $indir || ! -d $indir || ! $output) {
	die "usage: perl $0 -indir indir -output output.xls\n";
}

my %stat = ();

foreach my $f (glob("$indir/*/*.filter.stat.xls")) {
	my ($name) = $f =~ /.*\/(.*)\.filter.stat.xls/;
	open F,$f or die $!;
	while (<F>) {
		next if (/^\s*$/ || /^#/);
		chomp; my @a = split /\t+/;
		if (/Number of Reads/) {
			$stat{$name}{'raw_reads'} = $a[1];
			$stat{$name}{'clean_reads'} = $a[2];
		}elsif (/Data Size/) {
			$stat{$name}{'clean_bases'} = sprintf("%.2f", $a[2]/1000000000);
		}elsif (/GC\(%\) of fq1/) {
			$stat{$name}{'gc_fq1'} = $a[2];
		}elsif (/GC\(%\) of fq2/) {
			$stat{$name}{'gc_fq2'} = $a[2];
		}elsif (/Q20\(%\) of fq1/) {
			$stat{$name}{'q20_fq1'} = $a[2];
		}elsif (/Q20\(%\) of fq2/) {
			$stat{$name}{'q20_fq2'} = $a[2];
		}elsif (/Q30\(%\) of fq1/) {
			$stat{$name}{'q30_fq1'} = $a[2];
		}elsif (/Q30\(%\) of fq2/) {
			$stat{$name}{'q30_fq2'} = $a[2];
		}
	}
	close F;
}

open O,">$output" or die $!;
print O "Sample\tTotal Raw Reads(M)\tTotal Clean Reads(M)\tTotal Clean Bases(Gb)\tClean Reads Q20(%)\tClean Reads Q30(%)\tClean Reads Ratio(%)\n";
foreach my $s (sort keys %stat) {
	my $out = $s;
#	$stat{$s}{'q20'} = sprintf("%.2f",($stat{$s}{'q20_fq1'}+$stat{$s}{'q20_fq2'})/2);
#	$stat{$s}{'q30'} = sprintf("%.2f",($stat{$s}{'q30_fq1'}+$stat{$s}{'q30_fq2'})/2);
	$stat{$s}{'q20'} = ($stat{$s}{'q20_fq2'} && not $stat{$s}{'q20_fq2'} eq '-' )? sprintf("%.2f",($stat{$s}{'q20_fq1'}+$stat{$s}{'q20_fq2'})/2) : sprintf("%.2f",$stat{$s}{'q20_fq1'});
	$stat{$s}{'q30'} = ($stat{$s}{'q30_fq2'} && not $stat{$s}{'q30_fq2'} eq '-' )? sprintf("%.2f",($stat{$s}{'q30_fq1'}+$stat{$s}{'q30_fq2'})/2) : sprintf("%.2f",$stat{$s}{'q30_fq1'});
	$stat{$s}{'ratio'} = sprintf("%.2f", $stat{$s}{'clean_reads'}/$stat{$s}{'raw_reads'}*100);
	$stat{$s}{'raw_reads'} = sprintf("%.2f", $stat{$s}{'raw_reads'}/1000000);
	$stat{$s}{'clean_reads'} = sprintf("%.2f", $stat{$s}{'clean_reads'}/1000000);
	foreach my $k ("raw_reads", "clean_reads", "clean_bases", "q20", "q30", "ratio") {
		$out .= "\t$stat{$s}{$k}";
	}
	print O "$out\n";
}
close O;
