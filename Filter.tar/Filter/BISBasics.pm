package BISBasics;
require Exporter;
use strict;
use warnings;

#****************************************************************#
#                      lib inculded                              #
#****************************************************************#

use File::Basename qw(dirname basename);
use FindBin qw($Bin);
use Cwd;
use File::Spec qw(catfile);
use File::Basename qw(dirname basename);
use lib "$Bin/../lib/Log-Log4perl-1.36/lib/";
use lib "$Bin/../../lib/Log-Log4perl-1.36/lib/";

use Log::Log4perl qw(get_logger);

our @ISA = qw(Exporter);
our @EXPORT = qw(bis_check_permission bis_open bis_init_log bis_log bis_die_log
                 bis_evalopt bis_variable_name);

our $VERSION=1.0.0;

#****************************************************************#
#                      program head                              #
#****************************************************************#
=head
Function:               BIS Basic library
Version:                1.0.0
Author:                 zhangshichao@genomics.org.cn
Write Date:             2012-8-17
Latest Modified:        2012-8-28
                        2012-11-09:Perl::IO to pipe

=cut

#****************************************************************#
#                   variables' definition                        #
#****************************************************************#

our $Infologger;
our $Errorlogger;
our ($pipeline_error_log, $pipeline_info_log, $module_name, $caller_name);
our $pipeline_die_log = '';
our $cwd = getcwd();

#****************************************************************#
#                      library functions                         #
#****************************************************************#

sub bis_check_permission
{
    #######################################################
    #   �÷�    :    if( !bis_check_permission($location, $mode) ){#error...
    #   Ŀ��    :    ���Ŀ¼���ļ���Ȩ��.
    #   ����    :    �ɹ�����1, ʧ�ܷ���0.
    #   ����    :    $locationΪ������Ŀ¼���ļ�·��; $modeΪҪ����Ȩ���ִ�.
    #   ע��    :    $mode����ȡperl�й涨������Ȩ��, ˳����.

    my ($location, $mode) = @_;
    if (!defined $location || !defined $mode){
        return 0;
    }
    my @modes = split //, $mode;
    my $available = 1;

    foreach (@modes)
    {
        my $check_str = "if (!-$_ \"$location\")\n{\$available = 0;\n}";
        eval($check_str);    #if($@){print"$check_str\n";}
    }
    return $available;
}


sub bis_open
{
    #######################################################
    #   �÷�    :    if( !$file = bis_open($file_name, $pattern) ){#error...
    #   Ŀ��    :    ���ݴ�gz���ı��ļ�, ʹ�򿪷���һ��.
    #   ����    :    �ɹ�����1, ʧ�ܷ���0.
    #   ����    :    $file_nameΪ��򿪵��ļ�; $patternΪ�򿪷�ʽ.
    #   ע��    :    $pattern��ȡrֻ��, wֻд, a׷��.

    my ($file_name, $pattern)=@_;
    my$file;
    
    $pattern =~ s/r/\</i;
    $pattern =~ s/w/\>/i;
    $pattern =~ s/a/\>\>/i;
    
    if($pattern =~ /\>/)#����r, ��ϻ, ��>>��r.
    {
        my$dir = dirname $file_name;
        if(!-e $dir){
            if( system("mkdir -p $dir", "mkdir") )
            {
                return 0;
            }
        }
    }
    if($file_name =~ /\.gz/i && $pattern =~ /\>/)
    {
#        if(!open $file, "$pattern:gzip", $file_name)
#        {
#            return 0;
#        }
         if (!open $file, "| gzip > $file_name")
         {
             return 0;
         }
    }
    elsif($file_name =~ /\.gz/i && $pattern =~ /\</)
    {
          if (!open $file, "gzip -dc $file_name |")
          {
              return 0;
          }
    }
    elsif ($file_name =~ /\.gz/i && $pattern =~ /\>\>/)
    {
        if (!open $file, "| gzip >> $file_name")
        {
            return 0;
        }
    }
    else
    {
        if(!open $file, $pattern.$file_name)
        {
            #bis_log("can not open: $file_name", 'E');
            return 0;
        }
    }
    return $file;
}


sub bis_init_log
{
    #######################################################
    #   �÷�    :    if( !bis_init_log($error_log, $info_log, $module_name
    #                   , $caller_name) ){ #error...
    #   Ŀ��    :    ��ʼ��log4perl��־ϵͳ, ʹbis_log()��Ч.
    #   ����    :    �ɹ�����1, ʧ�ܷ���0.
    #   ����    :    4�������ֱ�Ϊ: ������־·��, ��Ϣ��־·��, ģ������, ������
    #                   ����
    #   ע��    :    ��ĳ����־����Ҫʱ, ���Կմ�.

    ($pipeline_error_log, $pipeline_info_log, $module_name, $caller_name) = @_;
    my $log_conf = "
    log4perl.logger.error=ERROR, ErrorFile
    log4perl.logger.info=INFO, InfoFile

    log4perl.appender.ErrorFile = Log::Log4perl::Appender::File
    log4perl.appender.ErrorFile.filename = $pipeline_error_log
    log4perl.appender.ErrorFile.mode=append
    log4perl.appender.ErrorFile.syswrite  = 1
    log4perl.appender.ErrorFile.layout = PatternLayout
    log4perl.appender.ErrorFile.layout.ConversionPattern = "
        ."$caller_name %d [%p]    %m%n

    log4perl.appender.InfoFile=Log::Log4perl::Appender::File
    log4perl.appender.InfoFile.filename = $pipeline_info_log
    log4perl.appender.InfoFile.mode = append
    log4perl.appender.InfoFile.syswrite  = 1
    log4perl.appender.InfoFile.layout=PatternLayout
    log4perl.appender.InfoFile.layout.ConversionPattern = "
        ."$module_name %d [%p]    %m%n
    ";  #Line: %L %d [%p]    ;
    my $err_conf = "
    log4perl.logger.error=ERROR, ErrorFile

    log4perl.appender.ErrorFile = Log::Log4perl::Appender::File
    log4perl.appender.ErrorFile.filename = $pipeline_error_log
    log4perl.appender.ErrorFile.mode=append
    log4perl.appender.ErrorFile.syswrite  = 1
    log4perl.appender.ErrorFile.layout = PatternLayout
    log4perl.appender.ErrorFile.layout.ConversionPattern = "
        ."$caller_name %d [%p]    %m%n";
        
    my $info_conf = "
    log4perl.logger.info=INFO, InfoFile
    
    log4perl.appender.InfoFile=Log::Log4perl::Appender::File
    log4perl.appender.InfoFile.filename = $pipeline_info_log
    log4perl.appender.InfoFile.mode = append
    log4perl.appender.InfoFile.syswrite  = 1
    log4perl.appender.InfoFile.layout=PatternLayout
    log4perl.appender.InfoFile.layout.ConversionPattern = "
        ."$module_name %d [%p]    %m%n
    "; # Line:%L %d [%p]    ;
    
    if ( ($pipeline_error_log.$pipeline_info_log) =~ /^\s?$/ )
    {
        return 0;
    }
    elsif ( $pipeline_info_log =~ /^\s?$/ )
    {
        $log_conf = $err_conf;
    }
    elsif ( $pipeline_error_log =~ /^\s?$/ )
    {
        $log_conf = $info_conf;
    }
    #print"$log_conf";
    Log::Log4perl::init( \$log_conf );
    $Errorlogger = get_logger("error");
    $Infologger  = get_logger("info");
    return 1;
}

sub bis_die_log
{
    #######################################################
    #   �÷�    :    bis_die_log($pipline_die_log);
    #   Ŀ��    :    ��ʼ���˳���־.
    #   ����    :    ��.
    #   ����    :    $pipline_die_logΪ�˳���־·��.
    #   ע��    :    ����bis_logдE, F�������־ʱ, ����ô˺�������ʼ��.
    
    $pipeline_die_log = shift;
}

sub bis_log
{
    #######################################################
    #   �÷�    :    if( !bis_log($log_flag, $log_message) ){ #error...
    #   Ŀ��    :    д������־
    #   ����    :    �ɹ�����1, ʧ�ܷ���0.
    #   ����    :    $log_flagΪ��־����, ����I, W, E, F; $log_messageΪ��־��Ϣ
    #                .
    #   ע��    :    ������E, F�������Ϣ, �Ὣ������־�����������˳���־�ļ�.

    my ($log_flag, $log_message) = @_;
    
    my $absolute_path = dirname($Bin);
    $log_message =~ s/$absolute_path\///g;
    
    $absolute_path = dirname($absolute_path);
    $log_message =~ s/$absolute_path\///g;
    
    my (undef, $the_caller, $calling_line) = caller();
    my $info_message = "Line:$calling_line $log_message";
    
    if ($log_flag =~ /I/i)
    {
        if ($pipeline_info_log ne '')
        {
            $Infologger->info("$info_message");
        }
        else
        {
            print STDERR "Info log doesn't exist!\n";
        }
    }
    
    if ($log_flag =~ /W/i)
    {
        if ($pipeline_info_log ne '')
        {
            $Infologger->warn("$info_message");
        }
        else
        {
            print STDERR "Info log doesn't exist!\n";
        }
    }
    
    if ($log_flag =~ /E/i)
    {
        if ($pipeline_info_log ne '')
        {
            $Infologger->error("$info_message");
        }
        else
        {
            print STDERR "Info log doesn't exist!\n";
        }
        
        if ($pipeline_error_log ne '')
        {
            $Errorlogger->error("$log_message");
        }
        else
        {
            print STDERR "Error log doesn't exist!\n";
        }
        
        my $log_cat_command = "cp $pipeline_error_log $pipeline_die_log";
        if( system("$log_cat_command") )
        {
            $Infologger->error("can't copy $pipeline_error_log to "
                ."$pipeline_die_log");
            $Errorlogger->error("can't copy $pipeline_error_log to "
                ."$pipeline_die_log");
            return 0;
        }
    }
    
    if ($log_flag =~ /F/i)
    {
        if ($pipeline_info_log ne '')
        {
            $Infologger->fatal("$info_message");
        }
        else
        {
            print STDERR "Info log doesn't exist!\n";
        }
        
        if ($pipeline_error_log ne '')
        {
            $Errorlogger->fatal("$log_message");
        }
        else
        {
            print STDERR "Error log doesn't exist!\n";
        }

        my $log_cat_command = "cp $pipeline_error_log $pipeline_die_log";
        if( system("$log_cat_command") )
        {
            $Infologger->error("can't copy $pipeline_error_log to "
                . "$pipeline_die_log");
            $Errorlogger->error("can't copy $pipeline_error_log to "
                . "$pipeline_die_log");
            return 0;
        }
    }
    return 1;
}

sub bis_evalopt
{
    #######################################################
    #   �÷�    :    my ($get_opt_str, $set_default_str) = 
    #                bis_evalopt($usage, $prefix);
    #   Ŀ��    :    ͨ��������ϢΪ������������в�����Ĭ��ֵ.
    #   ����    :    Getoptionsִ���ִ�$get_opt_str; Ĭ��ֵ�����ִ�
    #                $set_default_str.
    #   ����    :    ������Ϣ�ִ�$usage; ����ǰ׺�ִ�$prefix(��ʡ).
    #   ע��    :   
    
    my $usa = shift;
    my $var_prefix = shift || '';
    my ($vars_str, $type_str, $default_str) = _generate_vars_string($usa, 
        $var_prefix);
    my $get_opt_str = _generate_getopt_string($vars_str, $type_str, 
        $var_prefix);
    
    my $set_default_str = $default_str;
    
    my $var_type_str = '';
    my @vars_strs = split/\,/, $vars_str;
    my @type_strs = split/\,/, $type_str;
    for my $i (0..$#vars_strs)
    {
        $var_type_str .= "$vars_strs[$i]:$type_strs[$i] ; ";
    }
    return($get_opt_str, $set_default_str, $var_type_str);
}

sub bis_variable_name
{
    #######################################################
    #   �÷�    :    bis_variable_name($usage, $prefix);
    #   Ŀ��    :    �������������ַ���, ��ȥ�˹���д�ĺ�ʱ
    #   ����    :    ��Ļ�ϴ�ӡ�����������ִ�
    #   ����    :    ������Ϣ�ִ�$usage; ����ǰ׺�ִ�$prefix(��ʡ).
    #   ע��    :    ִ�к�����˳�; �ú�Ӧɾȥ.

    my $usa=shift;
    my $var_prefix = shift || '';
    my ($vars_str, $type_str) = _generate_vars_string($usa, $var_prefix);
    my $var_def_str = $vars_str;
    $var_def_str =~ s/\,$//;
    $var_def_str =~ s/\,/ \, /g;
    print "\nmy ($var_def_str);\n";
    die "\nbis_variable_name()\n";
}
    
sub _generate_vars_string
{
    my $usa = shift;
    my $var_prefix = shift;
    my ($vars_str, $type_str, $default_str) = ('','','');
    foreach my $zsc (split(/\n/,$usa))
    {
        my $var_name;
        my $type_name;
        my $switch_value = '';
        if($zsc=~/\-(\S+)\s*\<\s*(\w+)\s*\>\s*\:/)  #-in1_fq <s>:    fastq 1
        {
            $var_name  = $1;
            $type_name = $2;
            
            $vars_str .= "\$$var_prefix$var_name,";
            $type_str .= "$type_name,";
            
            if ( $type_name eq 'switch' )
            {
                if ($zsc =~ /default\s*\:\s*\[\s*(\S+)\s*\]/)
                {
                    $default_str .= "\$$var_prefix$var_name "
                        . "= \"$1\" if(!defined\$$var_prefix$var_name);\n";
                    $switch_value = $1;
                }
                $default_str .= "if(defined\$$var_prefix$var_name && "
                    . "\$$var_prefix$var_name ne 'off' && \$$var_prefix"
                    . "$var_name ne 'false'){\n";
                $default_str .= "    \$$var_prefix$var_name = 1;";
                $default_str .= "}else{ \$$var_prefix$var_name = 0; }\n";
            }
            elsif ($zsc=~/default\s*\:\s*\[\s*(\S+)\s*\]/)
            {
                $default_str .= "\$$var_prefix$var_name "
                    . "= \"$1\" if(!defined\$$var_prefix$var_name);\n";
            }
        }
    }
    return ($vars_str, $type_str, $default_str);
}

sub _generate_getopt_string
{
    #vars_str is like:  '$adapter1,$adapter2,$in1_fq,$in2_fq,$lowQual,'
    #type_str is like: 's,s,s,s,i,'
    my ($vars_str, $type_str, $var_prefix) = @_;
    
    my @variables = split/\,/,$vars_str;
    my @type_str  = split/\,/,$type_str;
    
    my $get_opt_str = "GetOptions(\n";
    foreach my$i(0..$#variables)
    {
        $variables[$i] =~ s/\$//;
        $variables[$i] =~ s/^$var_prefix//; #remove the prefix str;
        if($type_str[$i] eq 'switch')
        {
            $get_opt_str .= "    \"$variables[$i]\:s\"=>\\\$$var_prefix"
                . "$variables[$i],\n"; #switch SETS to type 's'(string), 
                                       #then you can design value like 'off' to 
                                       #disable it in calling programme.
        }
        else
        {
            $get_opt_str .= "    \"$variables[$i]\:$type_str[$i]\"=>"
                . "\\\$$var_prefix$variables[$i],\n";
        }
    }
    $get_opt_str .= ");\n";
    return $get_opt_str;
}



1;
