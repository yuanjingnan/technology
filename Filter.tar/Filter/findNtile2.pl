#!/usr/bin/perl -w
use strict;
use Getopt::Long;
use Cwd qw(abs_path);
use File::Basename;

my ($fq1,$fc1,$fq2,$fc2,$swath,$seqType,$help);
GetOptions("fq1:s"=>\$fq1,"fc1:s"=>\$fc1,"fq2:s"=>\$fq2,"fc2:s"=>\$fc2,"swath:i"=>\$swath,"seqType:i"=>\$seqType,"help"=>\$help);
usage () if(!defined $fq1 || defined $help);
$swath||=13;
$seqType ||=0;
my $N_rate=0.5;
process();
exit 0;

sub process{
  my $fqpath=dirname(abs_path($fq1));
  $fc1="$fqpath/1.fqcheck" if(!defined $fc1);
  my $out=findNtile(\$fq1,\$fc1);
  if(defined $fq2){
    $fc2="$fqpath/2.fqcheck" if(!defined $fc2);
	my $out2=findNtile(\$fq2,\$fc2);
    if($out ne " "){
	  $out.=",".$out2;
    }else{
	  $out=$out2;
    }
  }
  $out=~s/^?(\'\'\,)//;
  $out=~s/(\,\'\')//;
  if ($out =~ /^\s*$/) {
	  print $out;
  }else {
	  print "--tile $out";
  }
}

sub findNtile{
  my ($fq,$fc)=@_;
  my (%Ncycle,%Ntile,$total_base);
  open FC,"< $$fc" or die "failed to open $$fc\n";
  while(<FC>){
    next unless(/^base/);
    my @tmp=split /\s+/,$_;
    $Ncycle{$tmp[1]}="" if($tmp[6]>$N_rate);
  }
  close FC;
  if(keys %Ncycle){
    if($$fq=~/\.fq.gz$/){
      open FQ,"<:gzip",$$fq or die "failed to open $$fq\n";
    }else{
      open FQ,"< $$fq" or die "failed to open $$fq\n";
    }
    my $n=0;
    while(! eof FQ){
      if($n<50){
        <FQ>;<FQ>;<FQ>;<FQ>;$n++;
      }else{
        my $readId=<FQ>;
        my $tile="";
	
	#adjust for new fastq id, added by linruichai 2015-5-5
	if($seqType == 0){ $tile=(split /\:/,$readId)[2]; }elsif($seqType == 1){ $tile=(split /\:/,$readId)[4];}
        chomp(my $seq=<FQ>);
        my @base=split //,$seq;
        foreach my $ncycle(keys %Ncycle){
          $Ntile{$tile}{$ncycle}{$base[$ncycle-1]}++;
        }
        <FQ>;<FQ>;$n=0;
      }
    }
    close FQ;
    my (%outNtile,$outNtile);
    foreach my $tile(keys %Ntile) {
      foreach my $ncycle (keys %{$Ntile{$tile}}) {
        $Ntile{$tile}{$ncycle}{'A'}||=0;
        $Ntile{$tile}{$ncycle}{'T'}||=0;
        $Ntile{$tile}{$ncycle}{'C'}||=0;
        $Ntile{$tile}{$ncycle}{'G'}||=0;
        $Ntile{$tile}{$ncycle}{'N'}||=0;
        if($Ntile{$tile}{$ncycle}{'N'} > ($Ntile{$tile}{$ncycle}{'A'}+$Ntile{$tile}{$ncycle}{'T'}+$Ntile{$tile}{$ncycle}{'C'}+$Ntile{$tile}{$ncycle}{'G'})*0.1){
          if($tile<1200){
            $outNtile{'1'}{$tile}="";
          }elsif($tile<1300){
            $outNtile{'2'}{$tile}="";
          }elsif($tile<2100){
            $outNtile{'3'}{$tile}="";
          }elsif($tile<2200){
            $outNtile{'4'}{$tile}="";
          }elsif($tile<2300){
            $outNtile{'5'}{$tile}="";
          }elsif($tile<2400){
            $outNtile{'6'}{$tile}="";
          }
        }
      }
    }
    my %swath=(1=>[1101..1128],2=>[1201..1228],3=>[1301..1328],4=>[2101..2128],5=>[2201..2228],6=>[2301..2328]);
    for(my $i=1;$i<=6;$i++){
      if(keys %{$outNtile{$i}}>=$swath){
        $outNtile.=join ",",@{$swath{$i}};
        $outNtile.=",";
      }elsif(keys %{$outNtile{$i}}>0){
        $outNtile.=join ",",keys %{$outNtile{$i}};
        $outNtile.=",";
      }
    }
    if (!defined $outNtile) {
        $outNtile = " ";
    }
    $outNtile=~s/\,$//;
    return $outNtile;
  }else{
    return " ";
  }
}


sub usage{
  die qq/
Usage: perl $0 [options]

Options: -fq1   <s> * read1 or SE fastq
         -fc1   <s>   fqcheck of fq1, default *\/1.fqcheck
         -fq2   <s>   read2 
         -fc2   <s>   fqcheck of fq2, default *\/2.fqcheck
         -swath <i>   filter the whole swath when there were -swath tile need to be filtered, default 13
	 -seqType <i> sequencing fastq name type, 0 -> old fastq name, 1 -> new fastq name, default:0
		      old fastq name: \@FCD1PB1ACXX:4:1101:1799:2201#GAAGCACG\/2 
		      new fastq name: \@HISEQ:310:C5MH9ANXX:1:1101:3517:2043 2:N:0:TCGGTCAC
         -help        help information
\n/;
}
