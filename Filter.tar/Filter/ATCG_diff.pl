#!/usr/bin/perl
use strict;
use warnings;
use Getopt::Long;


my ($indir, $output);
GetOptions(
        "indir:s" => \$indir,
	"output:s" => \$output
);

if (! $indir || ! -d $indir || ! $output) 
{
        die "usage: perl $0 -indir indir -output output.xls\n";
}


open OUT, ">$output" or die $!;
print OUT "SampleName\tAT_separate\tCG_separate\n";
foreach my $path (glob("$indir/*/*/*[1-2].fqcheck"))
{
	my ($sample) = $path =~ /.*\/(.*)\.fqcheck/; 
	my ( $start, $sum_abs_at, $sum_abs_cg ) = (0, 0, 0);
	open IN, $path or die $!;
	while( <IN> ) 
	{
    		chomp;
    		if ( $_ =~ /^base/)
		{
			$start++;
			next if $start < 13;
			my ( $pos, $a, $c, $g, $t, $n ) = (split /\s+/, $_)[1,2,3,4,5,6];
	#		my $sum_total = $a+$c+$g+$t+$n;
			my $abs_at = abs( $a - $t );
			my $abs_cg = abs( $c - $g );
	#		my $cur_abs_at = abs( $a - $t );
        #		my $cur_abs_cg = abs( $c - $g );
	#		my $abs_at = $cur_abs_at/$sum_total;
	#		my $abs_cg = $cur_abs_cg/$sum_total;
			$sum_abs_at += $abs_at;
			$sum_abs_cg += $abs_cg;
	#		my $cur_at = $a - $t;
	#		my $cur_cg = $c - $g;
	#		my $at = $cur_at/$sum_total;
	#		my $cg = $cur_cg/$sum_total;
	#		$sum_at += $at;
	#		$sum_cg += $cg;
		}
	}
	close IN;
	my $len = $start - 12;
	$sum_abs_at = flt_to_pct( $sum_abs_at*0.01/$len );
	$sum_abs_cg = flt_to_pct( $sum_abs_cg*0.01/$len );
	#$sum_at = flt_to_pct( $sum_at/88 );
	#$sum_cg = flt_to_pct( $sum_cg/88 );

	print OUT "$sample.fq\t$sum_abs_at\t$sum_abs_cg\n";
}
close OUT;

sub flt_to_pct 
{
	sprintf( "%.4f", shift ) * 100 . '%';
}
